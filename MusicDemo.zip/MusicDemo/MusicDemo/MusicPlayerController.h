//
//  MusicNetPlayerController.h
//  MusicDemo
//
//  Created by olami on 2018/6/26.
//  Copyright © 2018年 VIA Technologies, Inc. & OLAMI Team. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 音乐的播放的控制类
 */
@protocol MusicPlayerControllerDelegate
- (void)setCurrentTime:(NSTimeInterval)time duration:(NSTimeInterval)duration;
- (void)playbackComplete;
- (void)updatePrograssBar:(NSTimeInterval)time;
- (void)playError;//播放出错。
@end;

@interface MusicPlayerController : NSObject
@property (nonatomic, copy) NSArray *musicDataArray;
@property (nonatomic, assign) SongStatus songStatus;
@property (nonatomic, assign) NSUInteger index;//当前播放歌曲的索引值
@property (nonatomic, weak) id<MusicPlayerControllerDelegate> delegate;
- (void)playIndex:(NSUInteger) index;
- (void)pause;
- (void)stop;
- (void)prevSong;
- (void)nextSong;
- (void)seekToTime:(NSTimeInterval)time;
- (void)seekStart;
- (void)seekEnd;
@end
