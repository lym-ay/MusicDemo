//
//  MusicViewModel.m
//  MusicDemo
//
//  Created by olami on 2018/6/25.
//  Copyright © 2018年 VIA Technologies, Inc. & OLAMI Team. All rights reserved.
//

#import "MusicViewModel.h"


@implementation MusicViewModel

- (id)init{
    if (self = [super init]) {
        _musicDataArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void)processMusic:(completeSearch)block{
    
}

 

@end
